README – Construct 3 hra (projektový súbor)

Tento priečinok obsahuje projekt vytvorený v nástroji Construct 3.

Súbor: `Hra.c3p`  
Obsahuje kompletný zdrojový súbor hry, ktorý možno otvoriť a spustiť v nástroji Construct 3 (cez webové rozhranie: https://editor.construct.net/).

Vzhľadom na to, že exportovanie hotovej hry yžaduje platenú verziu Construct 3, je v prílohe dostupný iba samotný projektový súbor `.c3p`.

Ak si chcete hru spustiť:
1. Otvorte stránku https://editor.construct.net/
2. Načítajte súbor `Hra.c3p` pomocou „File → Open“
3. Kliknite na „Play“ v hornom paneli → hra sa spustí v prehliadači

Tento projekt bol vytvorený ako súčasť praktickej časti bakalárskej práce a slúži na demonštráciu vývoja jednoduchej 2D endless runner hry v prostredí bez potreby programovania.

Autor: Samuel K.  
Rok: 2025