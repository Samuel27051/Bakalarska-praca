README – Stencyl hra (projektový súbor)

Tento priečinok obsahuje projekt vytvorený v nástroji Stencyl (verzia 4.1.4). 
Vzhľadom na obmedzenia bezplatnej verzie a problém s publikovaním do HTML5 nie je možné priložiť priamo spustiteľnú verziu hry (.exe alebo HTML5).

Ak si chcete hru zahrať alebo otestovať:

1. Stiahnite a nainštalujte nástroj Stencyl (https://www.stencyl.com/)
2. Otvorte aplikáciu a zvoľte možnosť File → Import Game
3. Vyberte súbor `Stencyl_Hra.stencyl` v tomto priečinku
4. Po importe kliknite na Test Game pre spustenie hry

Projekt obsahuje základnú endless runner hru, ktorá bola súčasťou praktickej časti bakalárskej práce.

Autor: Samuel K.  
Rok: 2025